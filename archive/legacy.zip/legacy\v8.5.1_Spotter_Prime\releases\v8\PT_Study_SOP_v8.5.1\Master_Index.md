# Master Index — PT Study SOP v8.5.1 (Spotter Prime)

## Version
- Current: v8.5.1 (Spotter Prime)
- Notes: Upgrades to Spotter Prime: Seed-Lock, Molding Logic, Phonetic Bridge, and Function-First Defaults.

## Package Files
- Custom_GPT_Instructions.md
- Module_1_Core_Protocol.md
- Module_6_Framework_Library.md
- Runtime_Prompt.md

## Legacy
- v8.4 Tutor Edition archive: legacy/v8.4_Tutor_Edition/
- Pre-safe-deploy v8.5.1 archive: legacy/v8.5.1_pre_safe_deploy/
