﻿# Session Log - YYYY-MM-DD

## Session Info
- Date: YYYY-MM-DD
- Time: HH:MM
- Topic: <topic>
- Study Mode: Sprint   # Sprint | Core | Drill
- Time Spent: <minutes> minutes

## Execution Details
- Frameworks Used: <comma-separated>
- Gated Platter Triggered: Yes   # Yes/No
- WRAP Phase Reached: Yes        # Yes/No
- Anki Cards Created: <number>
- Prompt Drift Noted: No         # Yes/No (if Yes, describe in Notes)

## Ratings
- Understanding Level: X/5
- Retention Confidence: X/5
- System Performance: X/5

## Reflection
### What Worked
- 

### What Needs Fixing
- 

### Notes/Insights
- 

