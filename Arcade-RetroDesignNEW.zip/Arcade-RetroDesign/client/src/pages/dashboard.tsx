import Layout from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Flame, Clock, BookOpen, AlertTriangle, Play, Check, Plus, Pencil, Trash2 } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

export default function Dashboard() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [minutes, setMinutes] = useState("");
  const [isCompleting, setIsCompleting] = useState(false);
  const [newCourseName, setNewCourseName] = useState("");
  const [showAddCourse, setShowAddCourse] = useState(false);
  const [editingCourse, setEditingCourse] = useState<{ id: number; name: string } | null>(null);
  const [editCourseName, setEditCourseName] = useState("");

  const { data: currentCourseData } = useQuery({
    queryKey: ["study-wheel", "current"],
    queryFn: api.studyWheel.getCurrentCourse,
  });

  const { data: courses = [] } = useQuery({
    queryKey: ["courses", "active"],
    queryFn: api.courses.getActive,
  });

  const { data: todaySessions = [] } = useQuery({
    queryKey: ["sessions", "today"],
    queryFn: api.todaySessions.get,
  });

  const { data: streakData } = useQuery({
    queryKey: ["streak"],
    queryFn: api.streak.get,
  });

  const { data: weaknessQueue = [] } = useQuery({
    queryKey: ["weakness-queue"],
    queryFn: api.weaknessQueue.get,
  });

  const completeSessionMutation = useMutation({
    mutationFn: ({ courseId, mins }: { courseId: number; mins: number }) =>
      api.studyWheel.completeSession(courseId, mins),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["study-wheel"] });
      queryClient.invalidateQueries({ queryKey: ["courses"] });
      queryClient.invalidateQueries({ queryKey: ["sessions"] });
      queryClient.invalidateQueries({ queryKey: ["streak"] });
      setMinutes("");
      setIsCompleting(false);
      toast({ title: "Session logged!", description: "Wheel rotated to next course." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to log session. Please try again.", variant: "destructive" });
    },
  });

  const addCourseMutation = useMutation({
    mutationFn: (name: string) => api.courses.create({ name, active: true, position: courses.length }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["courses"] });
      queryClient.invalidateQueries({ queryKey: ["study-wheel"] });
      setNewCourseName("");
      setShowAddCourse(false);
      toast({ title: "Course added!", description: "New course added to the wheel." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to add course. Please try again.", variant: "destructive" });
    },
  });

  const editCourseMutation = useMutation({
    mutationFn: ({ id, name }: { id: number; name: string }) => api.courses.update(id, { name }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["courses"] });
      queryClient.invalidateQueries({ queryKey: ["study-wheel"] });
      setEditingCourse(null);
      setEditCourseName("");
      toast({ title: "Course updated!", description: "Course name has been changed." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to update course. Please try again.", variant: "destructive" });
    },
  });

  const deleteCourseMutation = useMutation({
    mutationFn: (id: number) => api.courses.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["courses"] });
      queryClient.invalidateQueries({ queryKey: ["study-wheel"] });
      toast({ title: "Course deleted!", description: "Course has been removed from the wheel." });
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to delete course. Please try again.", variant: "destructive" });
    },
  });

  const currentCourse = currentCourseData?.currentCourse;
  const todayMinutes = todaySessions.reduce((sum, s) => sum + (s.minutes || 0), 0);
  const todaySessionCount = todaySessions.length;
  const hasStudiedToday = todaySessionCount > 0;

  const handleCompleteSession = () => {
    if (!currentCourse || !minutes || parseInt(minutes) < 1) return;
    completeSessionMutation.mutate({ courseId: currentCourse.id, mins: parseInt(minutes) });
  };

  const handleAddCourse = () => {
    if (!newCourseName.trim()) return;
    addCourseMutation.mutate(newCourseName.trim());
  };

  const handleEditCourse = () => {
    if (!editingCourse || !editCourseName.trim()) return;
    editCourseMutation.mutate({ id: editingCourse.id, name: editCourseName.trim() });
  };

  const handleDeleteCourse = (id: number) => {
    if (confirm("Are you sure you want to delete this course? This cannot be undone.")) {
      deleteCourseMutation.mutate(id);
    }
  };

  const startEditCourse = (course: { id: number; name: string }) => {
    setEditingCourse(course);
    setEditCourseName(course.name);
  };

  return (
    <Layout>
      <div className="space-y-6 max-w-5xl mx-auto">
        {/* Header: Title + Streak */}
        <div className="flex items-center justify-between">
          <h1 className="font-arcade text-xl text-primary">STUDY_CONTROL</h1>
          <div className="flex items-center gap-2 bg-black/40 border border-secondary px-4 py-2" data-testid="streak-display">
            <Flame className="w-5 h-5 text-orange-500" />
            <span className="font-arcade text-lg text-white" data-testid="text-streak">{streakData?.currentStreak || 0}</span>
            <span className="font-terminal text-xs text-muted-foreground">DAY STREAK</span>
          </div>
        </div>

        {/* Main Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {/* Study Wheel - Current Course */}
          <Card className="bg-black/40 border-2 border-primary rounded-none md:col-span-2">
            <CardHeader className="border-b border-primary/50 p-4">
              <CardTitle className="font-arcade text-sm flex items-center gap-2">
                <Play className="w-4 h-4" />
                STUDY_WHEEL
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              {courses.length === 0 ? (
                <div className="text-center py-8 space-y-4">
                  <p className="font-terminal text-muted-foreground">No courses added yet. Add courses to start the study wheel.</p>
                  <Dialog open={showAddCourse} onOpenChange={setShowAddCourse}>
                    <DialogTrigger asChild>
                      <Button variant="outline" className="rounded-none border-primary font-arcade" data-testid="button-add-first-course">
                        <Plus className="w-4 h-4 mr-2" />
                        ADD_COURSE
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="bg-black border-2 border-primary rounded-none">
                      <DialogHeader>
                        <DialogTitle className="font-arcade">ADD_NEW_COURSE</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4 pt-4">
                        <Input
                          placeholder="Course name (e.g., Anatomy)"
                          value={newCourseName}
                          onChange={(e) => setNewCourseName(e.target.value)}
                          className="rounded-none border-secondary bg-black font-terminal"
                          data-testid="input-course-name"
                        />
                        <Button
                          onClick={handleAddCourse}
                          disabled={!newCourseName.trim() || addCourseMutation.isPending}
                          className="w-full rounded-none font-arcade"
                          data-testid="button-confirm-add-course"
                        >
                          ADD
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Current Course Display */}
                  <div className="text-center space-y-2">
                    <p className="font-terminal text-muted-foreground text-sm">CURRENT COURSE</p>
                    <p className="font-arcade text-3xl text-primary" data-testid="text-current-course">
                      {currentCourse?.name || "LOADING..."}
                    </p>
                  </div>

                  {/* Wheel Visualization - Stacked vertically with edit/delete */}
                  <div className="flex flex-col gap-2 max-w-md mx-auto">
                    {courses.map((course, idx) => (
                      <div
                        key={course.id}
                        className={`flex items-center justify-between px-4 py-2 border ${
                          currentCourse?.id === course.id
                            ? "border-primary bg-primary/20"
                            : "border-secondary/50"
                        }`}
                        data-testid={`wheel-course-${course.id}`}
                      >
                        <span className={`font-terminal ${currentCourse?.id === course.id ? "text-primary" : "text-muted-foreground"}`}>
                          {idx + 1}. {course.name}
                        </span>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => startEditCourse({ id: course.id, name: course.name })}
                            className="p-1 hover:text-primary transition-colors text-muted-foreground"
                            data-testid={`button-edit-course-${course.id}`}
                          >
                            <Pencil className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => handleDeleteCourse(course.id)}
                            className="p-1 hover:text-red-500 transition-colors text-muted-foreground"
                            data-testid={`button-delete-course-${course.id}`}
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                    <Dialog open={showAddCourse} onOpenChange={setShowAddCourse}>
                      <DialogTrigger asChild>
                        <button
                          className="flex items-center justify-center px-4 py-2 border border-dashed border-secondary/50 text-muted-foreground hover:border-primary hover:text-primary transition-colors font-terminal"
                          data-testid="button-add-course-inline"
                        >
                          <Plus className="w-4 h-4 mr-2" />
                          ADD COURSE
                        </button>
                      </DialogTrigger>
                      <DialogContent className="bg-black border-2 border-primary rounded-none">
                        <DialogHeader>
                          <DialogTitle className="font-arcade">ADD_NEW_COURSE</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4 pt-4">
                          <Input
                            placeholder="Course name (e.g., Anatomy)"
                            value={newCourseName}
                            onChange={(e) => setNewCourseName(e.target.value)}
                            className="rounded-none border-secondary bg-black font-terminal"
                            data-testid="input-course-name-inline"
                          />
                          <Button
                            onClick={handleAddCourse}
                            disabled={!newCourseName.trim() || addCourseMutation.isPending}
                            className="w-full rounded-none font-arcade"
                            data-testid="button-confirm-add-course-inline"
                          >
                            ADD
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </div>

                  {/* Edit Course Dialog */}
                  <Dialog open={!!editingCourse} onOpenChange={(open) => !open && setEditingCourse(null)}>
                    <DialogContent className="bg-black border-2 border-primary rounded-none">
                      <DialogHeader>
                        <DialogTitle className="font-arcade">EDIT_COURSE</DialogTitle>
                      </DialogHeader>
                      <div className="space-y-4 pt-4">
                        <Input
                          placeholder="Course name"
                          value={editCourseName}
                          onChange={(e) => setEditCourseName(e.target.value)}
                          className="rounded-none border-secondary bg-black font-terminal"
                          data-testid="input-edit-course-name"
                        />
                        <Button
                          onClick={handleEditCourse}
                          disabled={!editCourseName.trim() || editCourseMutation.isPending}
                          className="w-full rounded-none font-arcade"
                          data-testid="button-confirm-edit-course"
                        >
                          SAVE
                        </Button>
                      </div>
                    </DialogContent>
                  </Dialog>

                  {/* Session Completion */}
                  {!isCompleting ? (
                    <div className="flex justify-center">
                      <Button
                        onClick={() => setIsCompleting(true)}
                        className="rounded-none font-arcade px-8 py-6 text-lg bg-primary hover:bg-primary/80"
                        disabled={!currentCourse}
                        data-testid="button-start-session"
                      >
                        <Check className="w-5 h-5 mr-2" />
                        COMPLETE SESSION
                      </Button>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center gap-4 p-4 border border-primary/50 bg-primary/5">
                      <p className="font-terminal text-sm text-muted-foreground">Enter minutes studied:</p>
                      <div className="flex items-center gap-3">
                        <Input
                          type="number"
                          min="1"
                          value={minutes}
                          onChange={(e) => setMinutes(e.target.value)}
                          placeholder="30"
                          className="w-24 rounded-none border-primary bg-black text-center font-arcade text-xl"
                          data-testid="input-minutes"
                          autoFocus
                        />
                        <span className="font-terminal text-muted-foreground">MIN</span>
                      </div>
                      <div className="flex gap-3">
                        <Button
                          variant="outline"
                          onClick={() => {
                            setIsCompleting(false);
                            setMinutes("");
                          }}
                          className="rounded-none font-arcade border-secondary"
                          data-testid="button-cancel-session"
                        >
                          CANCEL
                        </Button>
                        <Button
                          onClick={handleCompleteSession}
                          disabled={!minutes || parseInt(minutes) < 1 || completeSessionMutation.isPending}
                          className="rounded-none font-arcade bg-primary"
                          data-testid="button-log-session"
                        >
                          LOG & ROTATE
                        </Button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Today's Activity */}
          <Card className="bg-black/40 border-2 border-secondary rounded-none">
            <CardHeader className="border-b border-secondary p-4">
              <CardTitle className="font-arcade text-sm flex items-center gap-2">
                <Clock className="w-4 h-4" />
                TODAY
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4 space-y-4">
              <div className="flex items-center justify-between">
                <span className="font-terminal text-muted-foreground">Sessions</span>
                <span className="font-arcade text-xl text-white" data-testid="text-today-sessions">{todaySessionCount}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="font-terminal text-muted-foreground">Minutes</span>
                <span className="font-arcade text-xl text-primary" data-testid="text-today-minutes">{todayMinutes}</span>
              </div>
              <div className={`p-3 border ${hasStudiedToday ? "border-green-500/50 bg-green-500/10" : "border-orange-500/50 bg-orange-500/10"}`}>
                <span className={`font-terminal text-sm ${hasStudiedToday ? "text-green-400" : "text-orange-400"}`} data-testid="text-today-status">
                  {hasStudiedToday ? "STREAK MAINTAINED" : "NO SESSIONS TODAY - STUDY NOW!"}
                </span>
              </div>
            </CardContent>
          </Card>

          {/* Course Summary */}
          <Card className="bg-black/40 border-2 border-secondary rounded-none">
            <CardHeader className="border-b border-secondary p-4">
              <CardTitle className="font-arcade text-sm flex items-center gap-2">
                <BookOpen className="w-4 h-4" />
                COURSE_SUMMARY
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4 max-h-64 overflow-y-auto">
              {courses.length === 0 ? (
                <p className="font-terminal text-muted-foreground text-center py-4">No courses yet</p>
              ) : (
                <div className="space-y-3">
                  {courses.map((course) => (
                    <div
                      key={course.id}
                      className="flex items-center justify-between p-2 border border-secondary/30 hover:border-secondary transition-colors"
                      data-testid={`summary-course-${course.id}`}
                    >
                      <span className="font-terminal text-white">{course.name}</span>
                      <div className="flex items-center gap-4 text-sm font-terminal">
                        <span className="text-muted-foreground">
                          <span className="text-white" data-testid={`course-sessions-${course.id}`}>{course.totalSessions}</span> sess
                        </span>
                        <span className="text-muted-foreground">
                          <span className="text-primary" data-testid={`course-minutes-${course.id}`}>{course.totalMinutes}</span> min
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Weakness Queue (Read-only) */}
          <Card className="bg-black/40 border-2 border-secondary rounded-none md:col-span-2">
            <CardHeader className="border-b border-secondary p-4">
              <CardTitle className="font-arcade text-sm flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-orange-500" />
                WEAKNESS_QUEUE
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4">
              {weaknessQueue.length === 0 ? (
                <p className="font-terminal text-muted-foreground text-center py-4">
                  No flagged topics. Topics you struggle with will appear here.
                </p>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {weaknessQueue.map((item) => (
                    <div
                      key={item.id}
                      className="px-3 py-1 border border-orange-500/50 bg-orange-500/10 font-terminal text-sm text-orange-300"
                      data-testid={`weakness-${item.id}`}
                    >
                      {item.topic}
                      {item.reason && <span className="text-xs text-muted-foreground ml-2">({item.reason})</span>}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
