import Layout from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Database, Brain as BrainIcon, AlertTriangle, BookOpen, Layers, 
  FileText, Paperclip, Send, BarChart3, MessageCircle
} from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { api } from "@/lib/api";
import { format } from "date-fns";

export default function Brain() {
  const [chatInput, setChatInput] = useState("");
  const [chatMessages, setChatMessages] = useState<{ role: "user" | "assistant"; content: string }[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const { data: sessions = [], isLoading: sessionsLoading } = useQuery({
    queryKey: ["sessions"],
    queryFn: api.sessions.getAll,
  });

  const { data: metrics, isLoading: metricsLoading } = useQuery({
    queryKey: ["brain", "metrics"],
    queryFn: api.brain.getMetrics,
  });

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages]);

  const handleSendMessage = async () => {
    if (!chatInput.trim()) return;
    const message = chatInput;
    setChatInput("");
    setChatMessages(prev => [...prev, { role: "user", content: message }]);
    setIsProcessing(true);
    try {
      const result = await api.brain.chat(message);
      setChatMessages(prev => [...prev, { role: "assistant", content: result.response }]);
    } catch (error) {
      setChatMessages(prev => [...prev, { role: "assistant", content: "Error processing request. Please try again." }]);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async (e) => {
        const content = e.target?.result as string;
        setChatMessages(prev => [...prev, 
          { role: "user", content: `[Uploaded: ${file.name}]\n${content.slice(0, 500)}${content.length > 500 ? '...' : ''}` }
        ]);
        setIsProcessing(true);
        try {
          const result = await api.brain.ingest(content, file.name);
          setChatMessages(prev => [...prev, { role: "assistant", content: result.message }]);
        } catch (error) {
          setChatMessages(prev => [...prev, { role: "assistant", content: "Error processing file. Please try again." }]);
        } finally {
          setIsProcessing(false);
        }
      };
      reader.readAsText(file);
    }
  };

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="font-arcade text-xl text-primary flex items-center gap-2">
            <BrainIcon className="w-6 h-6" />
            BRAIN ANALYTICS
          </h1>
          <div className="flex items-center gap-4 font-terminal text-sm">
            <span className="text-muted-foreground">SESSIONS: <span className="text-primary" data-testid="text-total-sessions">{metrics?.totalSessions || 0}</span></span>
            <span className="text-muted-foreground">MINUTES: <span className="text-primary" data-testid="text-total-minutes">{metrics?.totalMinutes || 0}</span></span>
            <span className="text-muted-foreground">CARDS: <span className="text-primary" data-testid="text-total-cards">{metrics?.totalCards || 0}</span></span>
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Tabs defaultValue="evidence" className="w-full">
              <TabsList className="bg-black/40 border border-secondary rounded-none w-full justify-start">
                <TabsTrigger value="evidence" className="rounded-none font-arcade text-xs data-[state=active]:bg-primary data-[state=active]:text-black">
                  SESSION EVIDENCE
                </TabsTrigger>
                <TabsTrigger value="metrics" className="rounded-none font-arcade text-xs data-[state=active]:bg-primary data-[state=active]:text-black">
                  DERIVED METRICS
                </TabsTrigger>
                <TabsTrigger value="issues" className="rounded-none font-arcade text-xs data-[state=active]:bg-primary data-[state=active]:text-black">
                  ISSUES LOG
                </TabsTrigger>
              </TabsList>

              <TabsContent value="evidence" className="mt-4">
                <Card className="bg-black/40 border-2 border-secondary rounded-none">
                  <CardHeader className="border-b border-secondary p-4">
                    <CardTitle className="font-arcade text-sm flex items-center gap-2">
                      <Database className="w-4 h-4" />
                      SESSION EVIDENCE TABLE
                    </CardTitle>
                    <p className="font-terminal text-xs text-muted-foreground mt-1">
                      Raw WRAP data. Read-only. All metrics derive from these fields.
                    </p>
                  </CardHeader>
                  <CardContent className="p-0">
                    {sessionsLoading ? (
                      <div className="p-8 text-center font-terminal text-muted-foreground">LOADING...</div>
                    ) : sessions.length === 0 ? (
                      <div className="p-8 text-center font-terminal text-muted-foreground">NO SESSIONS YET</div>
                    ) : (
                      <ScrollArea className="h-[400px]">
                        <Table>
                          <TableHeader>
                            <TableRow className="border-secondary hover:bg-transparent">
                              <TableHead className="font-arcade text-xs text-primary">DATE</TableHead>
                              <TableHead className="font-arcade text-xs text-primary">COURSE</TableHead>
                              <TableHead className="font-arcade text-xs text-primary">MODE</TableHead>
                              <TableHead className="font-arcade text-xs text-primary">MIN</TableHead>
                              <TableHead className="font-arcade text-xs text-primary">CARDS</TableHead>
                              <TableHead className="font-arcade text-xs text-primary">CONFUSIONS</TableHead>
                              <TableHead className="font-arcade text-xs text-primary">CONCEPTS</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {sessions.map((session) => (
                              <TableRow key={session.id} className="border-secondary hover:bg-primary/10 font-terminal text-sm" data-testid={`row-session-${session.id}`}>
                                <TableCell className="text-muted-foreground">{format(new Date(session.date), 'MM/dd')}</TableCell>
                                <TableCell className="font-bold">{session.topic}</TableCell>
                                <TableCell>
                                  <Badge variant="outline" className="rounded-none border-secondary font-normal text-xs">{session.mode}</Badge>
                                </TableCell>
                                <TableCell>{session.minutes || 0}</TableCell>
                                <TableCell>{session.cards || 0}</TableCell>
                                <TableCell className="max-w-[150px] truncate text-xs text-muted-foreground">
                                  {(session.confusions || []).join(", ") || "-"}
                                </TableCell>
                                <TableCell className="max-w-[150px] truncate text-xs text-muted-foreground">
                                  {(session.concepts || []).slice(0, 3).join(", ") || "-"}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </ScrollArea>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="metrics" className="mt-4 space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <Card className="bg-black/40 border-2 border-secondary rounded-none">
                    <CardHeader className="border-b border-secondary p-3">
                      <CardTitle className="font-arcade text-xs flex items-center gap-2">
                        <BarChart3 className="w-3 h-3" />
                        SESSIONS PER COURSE
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-3 max-h-[200px] overflow-y-auto">
                      {metricsLoading ? (
                        <div className="text-center font-terminal text-xs text-muted-foreground">LOADING...</div>
                      ) : (metrics?.sessionsPerCourse || []).length === 0 ? (
                        <div className="text-center font-terminal text-xs text-muted-foreground py-4">NO DATA</div>
                      ) : (
                        <div className="space-y-2">
                          {metrics?.sessionsPerCourse.map((item, i) => (
                            <div key={i} className="flex items-center justify-between font-terminal text-xs">
                              <span className="truncate max-w-[120px]">{item.course}</span>
                              <div className="flex items-center gap-2">
                                <span className="text-primary">{item.count} sess</span>
                                <span className="text-muted-foreground">{item.minutes} min</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  <Card className="bg-black/40 border-2 border-secondary rounded-none">
                    <CardHeader className="border-b border-secondary p-3">
                      <CardTitle className="font-arcade text-xs flex items-center gap-2">
                        <Layers className="w-3 h-3" />
                        MODE DISTRIBUTION
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-3 max-h-[200px] overflow-y-auto">
                      {metricsLoading ? (
                        <div className="text-center font-terminal text-xs text-muted-foreground">LOADING...</div>
                      ) : (metrics?.modeDistribution || []).length === 0 ? (
                        <div className="text-center font-terminal text-xs text-muted-foreground py-4">NO DATA</div>
                      ) : (
                        <div className="space-y-2">
                          {metrics?.modeDistribution.map((item, i) => (
                            <div key={i} className="flex items-center justify-between font-terminal text-xs">
                              <Badge variant="outline" className="rounded-none border-secondary">{item.mode}</Badge>
                              <div className="flex items-center gap-2">
                                <span className="text-primary">{item.count} sess</span>
                                <span className="text-muted-foreground">{item.minutes} min</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  <Card className="bg-black/40 border-2 border-secondary rounded-none">
                    <CardHeader className="border-b border-secondary p-3">
                      <CardTitle className="font-arcade text-xs flex items-center gap-2 text-orange-400">
                        <AlertTriangle className="w-3 h-3" />
                        REPEATED CONFUSIONS
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-3 max-h-[200px] overflow-y-auto">
                      {(metrics?.recentConfusions || []).length === 0 ? (
                        <div className="text-center font-terminal text-xs text-muted-foreground py-4">NO CONFUSIONS LOGGED</div>
                      ) : (
                        <div className="space-y-1">
                          {metrics?.recentConfusions.map((item, i) => (
                            <div key={i} className="flex items-center justify-between font-terminal text-xs">
                              <span className="truncate max-w-[150px] text-orange-300">{item.text}</span>
                              <span className="text-muted-foreground">x{item.count}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  <Card className="bg-black/40 border-2 border-secondary rounded-none">
                    <CardHeader className="border-b border-secondary p-3">
                      <CardTitle className="font-arcade text-xs flex items-center gap-2">
                        <BookOpen className="w-3 h-3" />
                        CONCEPT FREQUENCY
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="p-3 max-h-[200px] overflow-y-auto">
                      {(metrics?.conceptFrequency || []).length === 0 ? (
                        <div className="text-center font-terminal text-xs text-muted-foreground py-4">NO CONCEPTS LOGGED</div>
                      ) : (
                        <div className="flex flex-wrap gap-1">
                          {metrics?.conceptFrequency.slice(0, 15).map((item, i) => (
                            <Badge key={i} variant="outline" className="rounded-none border-secondary font-terminal text-xs">
                              {item.concept} ({item.count})
                            </Badge>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="issues" className="mt-4">
                <Card className="bg-black/40 border-2 border-secondary rounded-none">
                  <CardHeader className="border-b border-secondary p-4">
                    <CardTitle className="font-arcade text-sm flex items-center gap-2 text-red-400">
                      <AlertTriangle className="w-4 h-4" />
                      ISSUES AND FAILURES LOG
                    </CardTitle>
                    <p className="font-terminal text-xs text-muted-foreground mt-1">
                      Aggregated session issues: interruptions, source-lock failures, workflow problems
                    </p>
                  </CardHeader>
                  <CardContent className="p-4">
                    {(metrics?.issuesLog || []).length === 0 ? (
                      <div className="text-center font-terminal text-muted-foreground py-8">NO ISSUES LOGGED</div>
                    ) : (
                      <div className="space-y-2">
                        {metrics?.issuesLog.map((item, i) => (
                          <div key={i} className="flex items-center justify-between p-2 border border-red-500/30 bg-red-500/5 font-terminal text-sm">
                            <span className="text-red-300">{item.issue}</span>
                            <div className="flex items-center gap-2">
                              <span className="text-muted-foreground text-xs">{item.course}</span>
                              <Badge variant="outline" className="rounded-none border-red-500/50 text-red-400">x{item.count}</Badge>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            <div className="grid md:grid-cols-2 gap-4">
              <Card className="bg-black/40 border-2 border-secondary/50 rounded-none">
                <CardHeader className="border-b border-secondary/50 p-3">
                  <CardTitle className="font-arcade text-xs flex items-center gap-2 text-muted-foreground">
                    <FileText className="w-3 h-3" />
                    OBSIDIAN INTEGRATION
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 text-center">
                  <p className="font-terminal text-xs text-muted-foreground">Integration stub - will display:</p>
                  <ul className="font-terminal text-xs text-muted-foreground mt-2 space-y-1">
                    <li>Notes created per session</li>
                    <li>Concepts linked</li>
                    <li>Orphan notes</li>
                  </ul>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-2 border-secondary/50 rounded-none">
                <CardHeader className="border-b border-secondary/50 p-3">
                  <CardTitle className="font-arcade text-xs flex items-center gap-2 text-muted-foreground">
                    <Layers className="w-3 h-3" />
                    ANKI INTEGRATION
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 text-center">
                  <p className="font-terminal text-xs text-muted-foreground">Integration stub - will display:</p>
                  <ul className="font-terminal text-xs text-muted-foreground mt-2 space-y-1">
                    <li>Cards created: {metrics?.totalCards || 0}</li>
                    <li>Review load (pending)</li>
                    <li>Lapses (pending)</li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>

          <div className="space-y-4">
            <Card className="bg-black/40 border-2 border-primary rounded-none h-[600px] flex flex-col">
              <CardHeader className="border-b border-primary/50 p-4">
                <CardTitle className="font-arcade text-sm flex items-center gap-2">
                  <MessageCircle className="w-4 h-4" />
                  LLM CHAT
                </CardTitle>
                <p className="font-terminal text-xs text-muted-foreground mt-1">
                  Ask questions about your study data
                </p>
              </CardHeader>
              <CardContent className="flex-1 flex flex-col p-0 overflow-hidden">
                <ScrollArea className="flex-1 p-4">
                  <div className="space-y-3">
                    {chatMessages.length === 0 ? (
                      <div className="text-center font-terminal text-xs text-muted-foreground py-8">
                        Start a conversation or upload files.<br />
                        Ask about your study patterns, concepts, or get summaries.
                      </div>
                    ) : (
                      chatMessages.map((msg, i) => (
                        <div key={i} className={`p-3 font-terminal text-sm ${
                          msg.role === "user" 
                            ? "bg-primary/10 border-l-2 border-primary ml-4" 
                            : "bg-secondary/10 border-l-2 border-secondary mr-4"
                        }`}>
                          <p className="whitespace-pre-wrap">{msg.content}</p>
                        </div>
                      ))
                    )}
                    {isProcessing && (
                      <div className="p-3 font-terminal text-sm text-muted-foreground animate-pulse bg-secondary/10 border-l-2 border-secondary mr-4">
                        Thinking...
                      </div>
                    )}
                    <div ref={chatEndRef} />
                  </div>
                </ScrollArea>
                <div className="border-t border-primary/50 p-3">
                  <div className="flex gap-2 items-center">
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileUpload}
                      accept=".txt,.json,.md,.csv"
                      className="hidden"
                    />
                    <Button
                      variant="ghost"
                      size="icon"
                      className="rounded-none h-10 w-10 shrink-0"
                      onClick={() => fileInputRef.current?.click()}
                      data-testid="button-upload-file"
                      title="Attach file"
                    >
                      <Paperclip className="w-4 h-4" />
                    </Button>
                    <Input
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      placeholder="Type a message..."
                      className="rounded-none border-secondary bg-black font-terminal text-sm"
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && !e.shiftKey) {
                          e.preventDefault();
                          handleSendMessage();
                        }
                      }}
                      data-testid="input-chat"
                    />
                    <Button
                      size="icon"
                      className="rounded-none bg-primary h-10 w-10 shrink-0"
                      onClick={handleSendMessage}
                      disabled={!chatInput.trim() || isProcessing}
                      data-testid="button-send-chat"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </Layout>
  );
}
