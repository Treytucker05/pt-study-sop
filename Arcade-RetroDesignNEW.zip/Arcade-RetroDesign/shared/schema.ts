import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Courses for Study Wheel round-robin
export const courses = pgTable("courses", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  name: text("name").notNull(),
  active: boolean("active").notNull().default(true),
  position: integer("position").notNull().default(0), // Round-robin order position
  totalSessions: integer("total_sessions").notNull().default(0),
  totalMinutes: integer("total_minutes").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertCourseSchema = createInsertSchema(courses).omit({
  id: true,
  createdAt: true,
  totalSessions: true,
  totalMinutes: true,
});

export type InsertCourse = z.infer<typeof insertCourseSchema>;
export type Course = typeof courses.$inferSelect;

// Study sessions with WRAP fields for Brain analytics
// WRAP = Weekly Review And Planning session output
export const sessions = pgTable("sessions", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  date: timestamp("date").notNull().defaultNow(),
  topic: text("topic").notNull(), // Course name for backward compatibility
  courseId: integer("course_id"), // Links to courses table
  mode: text("mode").notNull(), // WRAP: study mode (Core, Sprint, Drill, etc.)
  duration: text("duration").notNull(), // Keep for backward compatibility
  minutes: integer("minutes").notNull().default(0), // WRAP: actual minutes studied
  errors: integer("errors").notNull().default(0), // Legacy field
  cards: integer("cards").notNull().default(0), // WRAP: cards drafted during session
  notes: text("notes"),
  // WRAP fields for Brain analytics
  confusions: text("confusions").array(), // WRAP: concepts that caused confusion
  weakAnchors: text("weak_anchors").array(), // WRAP: topics needing reinforcement
  concepts: text("concepts").array(), // WRAP: concepts touched during session
  issues: text("issues").array(), // WRAP: interruptions, source-lock failures, workflow problems
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertSessionSchema = createInsertSchema(sessions).omit({
  id: true,
  createdAt: true,
});

export type InsertSession = z.infer<typeof insertSessionSchema>;
export type Session = typeof sessions.$inferSelect;

// Study Wheel state - tracks current position in round-robin
export const studyWheelState = pgTable("study_wheel_state", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  currentCourseId: integer("current_course_id"), // Current course to study
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

// Study streak tracking
export const studyStreak = pgTable("study_streak", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  currentStreak: integer("current_streak").notNull().default(0),
  longestStreak: integer("longest_streak").notNull().default(0),
  lastStudyDate: timestamp("last_study_date"),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Weakness queue - flagged topics for review
export const weaknessQueue = pgTable("weakness_queue", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  topic: text("topic").notNull(),
  courseId: integer("course_id"),
  reason: text("reason"),
  flaggedAt: timestamp("flagged_at").notNull().defaultNow(),
});

export const calendarEvents = pgTable("calendar_events", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  title: text("title").notNull(),
  date: timestamp("date").notNull(),
  endDate: timestamp("end_date"),
  allDay: boolean("all_day").default(false),
  eventType: text("event_type").notNull(),
  course: text("course"),
  weight: text("weight"),
  notes: text("notes"),
  status: text("status").default("pending"),
  color: text("color").default("#ef4444"),
  recurrence: text("recurrence"),
  calendarId: text("calendar_id"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertCalendarEventSchema = createInsertSchema(calendarEvents).omit({
  id: true,
  createdAt: true,
});

export type InsertCalendarEvent = z.infer<typeof insertCalendarEventSchema>;
export type CalendarEvent = typeof calendarEvents.$inferSelect;

export const tasks = pgTable("tasks", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  title: text("title").notNull(),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
  createdAt: true,
});

export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

export const proposals = pgTable("proposals", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  proposalId: text("proposal_id").notNull().unique(),
  summary: text("summary").notNull(),
  status: text("status").notNull().default("DRAFT"),
  priority: text("priority").notNull().default("MED"),
  targetSystem: text("target_system"),
  evidence: jsonb("evidence"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertProposalSchema = createInsertSchema(proposals).omit({
  id: true,
  createdAt: true,
});

export type InsertProposal = z.infer<typeof insertProposalSchema>;
export type Proposal = typeof proposals.$inferSelect;

export const chatMessages = pgTable("chat_messages", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  sessionId: text("session_id").notNull(),
  sender: text("sender").notNull(),
  content: text("content").notNull(),
  metadata: jsonb("metadata"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  createdAt: true,
});

export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type ChatMessage = typeof chatMessages.$inferSelect;

export const googleTokens = pgTable("google_tokens", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  accessToken: text("access_token").notNull(),
  refreshToken: text("refresh_token"),
  expiresAt: timestamp("expires_at"),
  scope: text("scope"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export type GoogleToken = typeof googleTokens.$inferSelect;

export const notes = pgTable("notes", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  content: text("content").notNull(),
  position: integer("position").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertNoteSchema = createInsertSchema(notes).omit({
  id: true,
  createdAt: true,
});

export type InsertNote = z.infer<typeof insertNoteSchema>;
export type Note = typeof notes.$inferSelect;

// AI Chat conversations for calendar assistant
export const conversations = pgTable("conversations", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  title: text("title").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const messages = pgTable("messages", {
  id: integer("id").primaryKey().generatedAlwaysAsIdentity(),
  conversationId: integer("conversation_id").notNull(),
  role: text("role").notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Conversation = typeof conversations.$inferSelect;
export type Message = typeof messages.$inferSelect;
