﻿# Engine Template (stub)

Use this stub to draft new engines (pathology, exam-prep, etc.). Fill in:
- Entry prompt(s)
- State machine / phases
- Gating rules (Seed-Lock, L2 teach-back, etc.)
- RAG requirements and source expectations
- Outputs (session log fields touched, any card payloads)
