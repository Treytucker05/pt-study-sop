﻿# Core Protocol (v7.4 summary)
- Single-session MAP → LOOP → WRAP flow.
- Seed-first; function-before-structure; Level gating L1–L4.
- Sprint/Core/Drill modes present but less formal than v8+.
