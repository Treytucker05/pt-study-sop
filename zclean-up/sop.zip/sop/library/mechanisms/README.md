﻿# Mechanisms Index

- v9.1: see operating rules in `../gpt-instructions.md` and `../modules/M4-build.md`, `M5-modes.md`, `M6-wrap.md`.
- v8.6: `v8.6.md` (Gated Platter, Seed-Lock, Phonetic Override, Level Gating, WRAP card rule).
