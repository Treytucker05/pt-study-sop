﻿# Prompts Index

- v9.1: `../gpt-instructions.md`, `../runtime-prompt.md`.
- v8.6: `v8.6_custom_instructions.md`, `v8.6_runtime_prompt.md`.
