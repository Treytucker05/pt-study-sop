# BUILD ORDER
## Paste into Custom GPT Instructions
- gpt-instructions.md

## Upload as Knowledge
- PEIRRO.md
- KWIK.md
- levels.md
- H-series.md
- M-series.md
- Y-series.md
- M0-planning.md
- M1-entry.md
- M2-prime.md
- M3-encode.md
- M4-build.md
- M5-modes.md
- M6-wrap.md
- anatomy-engine.md
- concept-engine.md
- notebooklm-bridge.md
- brain-session-log-template.md

## Paste each session
- runtime-prompt.md
